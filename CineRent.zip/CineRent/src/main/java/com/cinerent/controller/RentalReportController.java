package com.cinerent.controller;

import com.cinerent.service.RentalReportService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;

@Controller
@RequestMapping("/reports/rentals")
public class RentalReportController {

    private final RentalReportService service;

    public RentalReportController(RentalReportService service) {
        this.service = service;
    }

    @GetMapping
    public String rentals(
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(required = false) Integer storeId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            Model model
    ) {
        LocalDate fromDate = (from != null && !from.isBlank()) ? LocalDate.parse(from) : null;
        LocalDate toDate = (to != null && !to.isBlank()) ? LocalDate.parse(to) : null;

        var rows = service.search(fromDate, toDate, storeId, page, size);
        long total = service.count(fromDate, toDate, storeId);

        model.addAttribute("rows", rows);
        model.addAttribute("total", total);
        model.addAttribute("page", page);
        model.addAttribute("size", size);

        // Mantener filtros en la vista
        model.addAttribute("from", from);
        model.addAttribute("to", to);
        model.addAttribute("storeId", storeId);

        return "reports/rentals";
    }
}
