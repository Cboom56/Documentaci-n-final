package com.cinerent.repository;

import com.cinerent.dto.FilmRow;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class FilmDao {

    private final JdbcTemplate jdbcTemplate;

    public FilmDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<FilmRow> mapper = (rs, rowNum) -> new FilmRow(
            rs.getInt("film_id"),
            rs.getString("title"),
            rs.getString("rating"),
            rs.getObject("release_year", Integer.class),
            rs.getObject("length", Integer.class),
            rs.getString("category")
    );

    public List<FilmRow> search(String title, String rating, String category, String actor, int page, int size) {

        StringBuilder sql = new StringBuilder("""
            SELECT DISTINCT
                   f.film_id,
                   f.title,
                   f.rating::text AS rating,
                   f.release_year,
                   f.length,
                   c.name AS category
            FROM film f
            JOIN film_category fc ON fc.film_id = f.film_id
            JOIN category c ON c.category_id = fc.category_id
            WHERE 1=1
        """);

        List<Object> params = new ArrayList<>();

        if (title != null && !title.isBlank()) {
            sql.append(" AND LOWER(f.title) LIKE ? ");
            params.add("%" + title.trim().toLowerCase() + "%");
        }

        if (rating != null && !rating.isBlank()) {
            sql.append(" AND f.rating::text = ? ");
            params.add(rating.trim());
        }

        if (category != null && !category.isBlank()) {
            sql.append(" AND c.name = ? ");
            params.add(category.trim());
        }

        if (actor != null && !actor.isBlank()) {
            sql.append("""
                AND EXISTS (
                    SELECT 1
                    FROM film_actor fa
                    JOIN actor a ON a.actor_id = fa.actor_id
                    WHERE fa.film_id = f.film_id
                      AND (LOWER(a.first_name) LIKE ? OR LOWER(a.last_name) LIKE ?)
                )
            """);
            String like = "%" + actor.trim().toLowerCase() + "%";
            params.add(like);
            params.add(like);
        }

        sql.append(" ORDER BY f.title ");
        sql.append(" LIMIT ? OFFSET ? ");

        params.add(size);
        params.add(page * size);

        return jdbcTemplate.query(sql.toString(), mapper, params.toArray());
    }

    public long count(String title, String rating, String category, String actor) {

        StringBuilder sql = new StringBuilder("""
            SELECT COUNT(DISTINCT f.film_id)
            FROM film f
            JOIN film_category fc ON fc.film_id = f.film_id
            JOIN category c ON c.category_id = fc.category_id
            WHERE 1=1
        """);

        List<Object> params = new ArrayList<>();

        if (title != null && !title.isBlank()) {
            sql.append(" AND LOWER(f.title) LIKE ? ");
            params.add("%" + title.trim().toLowerCase() + "%");
        }

        if (rating != null && !rating.isBlank()) {
            sql.append(" AND f.rating::text = ? ");
            params.add(rating.trim());
        }

        if (category != null && !category.isBlank()) {
            sql.append(" AND c.name = ? ");
            params.add(category.trim());
        }

        if (actor != null && !actor.isBlank()) {
            sql.append("""
                AND EXISTS (
                    SELECT 1
                    FROM film_actor fa
                    JOIN actor a ON a.actor_id = fa.actor_id
                    WHERE fa.film_id = f.film_id
                      AND (LOWER(a.first_name) LIKE ? OR LOWER(a.last_name) LIKE ?)
                )
            """);
            String like = "%" + actor.trim().toLowerCase() + "%";
            params.add(like);
            params.add(like);
        }

        return jdbcTemplate.queryForObject(sql.toString(), Long.class, params.toArray());
    }
}
