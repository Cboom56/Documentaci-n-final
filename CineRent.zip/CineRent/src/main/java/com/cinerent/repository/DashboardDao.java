package com.cinerent.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class DashboardDao {

    private final JdbcTemplate jdbcTemplate;

    public DashboardDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // Alquileres recientes (últimos 7 días)
    public long countRecentRentals7Days() {
        String sql = """
                SELECT COUNT(*)
                FROM rental
                WHERE last_update >= (CURRENT_DATE - INTERVAL '7 days')
                """;
        return jdbcTemplate.queryForObject(sql, Long.class);
    }

    // Clientes activos (últimos 30 días)
    public long countActiveCustomers30Days() {
        String sql = """
                SELECT COUNT(DISTINCT customer_id)
                FROM rental
                WHERE last_update >= (CURRENT_DATE - INTERVAL '30 days')
                """;
        return jdbcTemplate.queryForObject(sql, Long.class);
    }

    // Ingresos totales
    public BigDecimal sumTotalRevenue() {
        String sql = """
                SELECT COALESCE(SUM(amount), 0)
                FROM payment
                """;
        return jdbcTemplate.queryForObject(sql, BigDecimal.class);
    }
}
