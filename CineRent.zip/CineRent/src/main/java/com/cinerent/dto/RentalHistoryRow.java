package com.cinerent.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class RentalHistoryRow {
    private int rentalId;
    private LocalDateTime rentalDate;
    private LocalDateTime returnDate;
    private String filmTitle;
    private BigDecimal totalPaid;

    public RentalHistoryRow(int rentalId, LocalDateTime rentalDate, LocalDateTime returnDate, String filmTitle, BigDecimal totalPaid) {
        this.rentalId = rentalId;
        this.rentalDate = rentalDate;
        this.returnDate = returnDate;
        this.filmTitle = filmTitle;
        this.totalPaid = totalPaid;
    }

    public int getRentalId() { return rentalId; }
    public LocalDateTime getRentalDate() { return rentalDate; }
    public LocalDateTime getReturnDate() { return returnDate; }
    public String getFilmTitle() { return filmTitle; }
    public BigDecimal getTotalPaid() { return totalPaid; }
}
