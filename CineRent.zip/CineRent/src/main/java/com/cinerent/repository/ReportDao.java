package com.cinerent.repository;

import com.cinerent.dto.MonthlyRevenueRow;
import com.cinerent.dto.TopFilmRow;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.cinerent.dto.TopCustomerRow;

import java.util.List;

@Repository
public class ReportDao {

    private final JdbcTemplate jdbcTemplate;

    public ReportDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // Top películas por número de alquileres
    public List<TopFilmRow> topFilms(int limit) {
        String sql = """
            SELECT f.title, COUNT(*) AS rentals
            FROM rental r
            JOIN inventory i ON i.inventory_id = r.inventory_id
            JOIN film f ON f.film_id = i.film_id
            GROUP BY f.title
            ORDER BY rentals DESC
            LIMIT ?
        """;

        return jdbcTemplate.query(sql, (rs, rowNum) ->
                new TopFilmRow(rs.getString("title"), rs.getLong("rentals")), limit);
    }

    // Ingresos por mes (últimos 12 meses)
    // 1) Intenta con payment_date
    // 2) Si no existe, usa last_update como fallback
 // Top clientes por gasto total
    public List<TopCustomerRow> topCustomersBySpending(int limit) {

        String sql = """
            SELECT c.customer_id,
                   (c.first_name || ' ' || c.last_name) AS full_name,
                   c.email,
                   COALESCE(SUM(p.amount), 0) AS total_spent
            FROM customer c
            JOIN payment p ON p.customer_id = c.customer_id
            GROUP BY c.customer_id, c.first_name, c.last_name, c.email
            ORDER BY total_spent DESC
            LIMIT ?
        """;

        return jdbcTemplate.query(sql, (rs, rowNum) ->
                new TopCustomerRow(
                        rs.getInt("customer_id"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getBigDecimal("total_spent")
                ), limit);
    }

    public List<MonthlyRevenueRow> revenueLast12Months() {

        String sqlPaymentDate = """
            SELECT to_char(date_trunc('month', p.payment_date), 'YYYY-MM') AS month,
                   COALESCE(SUM(p.amount), 0) AS revenue
            FROM payment p
            WHERE p.payment_date >= (CURRENT_DATE - INTERVAL '12 months')
            GROUP BY date_trunc('month', p.payment_date)
            ORDER BY date_trunc('month', p.payment_date)
        """;

        String sqlLastUpdate = """
            SELECT to_char(date_trunc('month', p.last_update), 'YYYY-MM') AS month,
                   COALESCE(SUM(p.amount), 0) AS revenue
            FROM payment p
            WHERE p.last_update >= (CURRENT_DATE - INTERVAL '12 months')
            GROUP BY date_trunc('month', p.last_update)
            ORDER BY date_trunc('month', p.last_update)
        """;

        try {
            return jdbcTemplate.query(sqlPaymentDate, (rs, rowNum) ->
                    new MonthlyRevenueRow(rs.getString("month"), rs.getBigDecimal("revenue")));
        } catch (Exception ex) {
            // Fallback por si payment_date no existe
            return jdbcTemplate.query(sqlLastUpdate, (rs, rowNum) ->
                    new MonthlyRevenueRow(rs.getString("month"), rs.getBigDecimal("revenue")));
        }
    }
}
