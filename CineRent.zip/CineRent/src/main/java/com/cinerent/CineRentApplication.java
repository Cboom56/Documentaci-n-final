package com.cinerent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CineRentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CineRentApplication.class, args);
	}

}
