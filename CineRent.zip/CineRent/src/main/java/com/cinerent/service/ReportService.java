package com.cinerent.service;

import com.cinerent.dto.MonthlyRevenueRow;
import com.cinerent.dto.TopFilmRow;
import com.cinerent.repository.ReportDao;
import org.springframework.stereotype.Service;

import java.util.List;
import com.cinerent.dto.TopCustomerRow;
import java.util.List;

@Service
public class ReportService {

    private final ReportDao reportDao;

    public ReportService(ReportDao reportDao) {
        this.reportDao = reportDao;
    }

    public List<TopFilmRow> topFilms() {
        return reportDao.topFilms(10);
    }
    
    public List<TopCustomerRow> topCustomersBySpending() {
        return reportDao.topCustomersBySpending(10); // Top 10 por defecto
    }

    public List<MonthlyRevenueRow> revenueLast12Months() {
        return reportDao.revenueLast12Months();
    }
}
