package com.cinerent.service;

import com.cinerent.dto.FilmRow;
import com.cinerent.repository.FilmDao;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FilmSearchService {

    private final FilmDao filmDao;

    public FilmSearchService(FilmDao filmDao) {
        this.filmDao = filmDao;
    }

    public List<FilmRow> search(String title, String rating, String category, String actor, int page, int size) {
        return filmDao.search(title, rating, category, actor, page, size);
    }

    public long count(String title, String rating, String category, String actor) {
        return filmDao.count(title, rating, category, actor);
    }
}
