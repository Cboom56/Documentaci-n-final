package com.cinerent.service;

import com.cinerent.dto.RentalRow;
import com.cinerent.repository.RentalReportDao;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class RentalReportService {

    private final RentalReportDao dao;

    public RentalReportService(RentalReportDao dao) {
        this.dao = dao;
    }

    public List<RentalRow> search(LocalDate from, LocalDate to, Integer storeId, int page, int size) {
        return dao.searchRentals(from, to, storeId, page, size);
    }

    public long count(LocalDate from, LocalDate to, Integer storeId) {
        return dao.countRentals(from, to, storeId);
    }
}
