package com.cinerent.service;

import com.cinerent.dto.DashboardStats;
import com.cinerent.repository.DashboardDao;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class DashboardService {

    private final DashboardDao dashboardDao;

    public DashboardService(DashboardDao dashboardDao) {
        this.dashboardDao = dashboardDao;
    }

    public DashboardStats getStats() {
        long rentalsRecent = dashboardDao.countRecentRentals7Days();
        BigDecimal revenueTotal = dashboardDao.sumTotalRevenue();
        long activeCustomers = dashboardDao.countActiveCustomers30Days();

        return new DashboardStats(rentalsRecent, revenueTotal, activeCustomers);
    }
}
