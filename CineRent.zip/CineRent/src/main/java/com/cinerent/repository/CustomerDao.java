package com.cinerent.repository;

import com.cinerent.dto.CustomerRow;
import com.cinerent.dto.RentalHistoryRow;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CustomerDao {

    private final JdbcTemplate jdbcTemplate;

    public CustomerDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<CustomerRow> customerMapper = (rs, rowNum) -> new CustomerRow(
            rs.getInt("customer_id"),
            rs.getString("full_name"),
            rs.getString("email"),
            rs.getString("phone"),
            rs.getInt("active") == 1
    );

    // OJO: en tu BD no existe r.return_date, por eso aquí NO se lee return_date
    private final RowMapper<RentalHistoryRow> rentalMapper = (rs, rowNum) -> {
        Timestamp rentalTs = rs.getTimestamp("rental_date"); // viene de last_update AS rental_date
        LocalDateTime rentalDate = rentalTs != null ? rentalTs.toLocalDateTime() : null;

        return new RentalHistoryRow(
                rs.getInt("rental_id"),
                rentalDate,
                null, // return_date no existe en esta BD
                rs.getString("title"),
                rs.getBigDecimal("total_paid")
        );
    };

    // Lista clientes con filtro por nombre/apellido/email y paginación
    public List<CustomerRow> searchCustomers(String q, int page, int size) {

        StringBuilder sql = new StringBuilder("""
            SELECT c.customer_id,
                   (c.first_name || ' ' || c.last_name) AS full_name,
                   c.email,
                   a.phone,
                   c.active
            FROM customer c
            JOIN address a ON a.address_id = c.address_id
            WHERE 1=1
        """);

        List<Object> params = new ArrayList<>();

        if (q != null && !q.isBlank()) {
            sql.append(" AND (LOWER(c.first_name) LIKE ? OR LOWER(c.last_name) LIKE ? OR LOWER(c.email) LIKE ?) ");
            String like = "%" + q.trim().toLowerCase() + "%";
            params.add(like);
            params.add(like);
            params.add(like);
        }

        sql.append(" ORDER BY c.last_name, c.first_name ");
        sql.append(" LIMIT ? OFFSET ? ");

        params.add(size);
        params.add(page * size);

        return jdbcTemplate.query(sql.toString(), customerMapper, params.toArray());
    }

    public long countCustomers(String q) {

        StringBuilder sql = new StringBuilder("""
            SELECT COUNT(*)
            FROM customer c
            WHERE 1=1
        """);

        List<Object> params = new ArrayList<>();

        if (q != null && !q.isBlank()) {
            sql.append(" AND (LOWER(c.first_name) LIKE ? OR LOWER(c.last_name) LIKE ? OR LOWER(c.email) LIKE ?) ");
            String like = "%" + q.trim().toLowerCase() + "%";
            params.add(like);
            params.add(like);
            params.add(like);
        }

        return jdbcTemplate.queryForObject(sql.toString(), Long.class, params.toArray());
    }

    // Detalle de cliente (datos básicos)
    public CustomerRow getCustomer(int customerId) {
        String sql = """
            SELECT c.customer_id,
                   (c.first_name || ' ' || c.last_name) AS full_name,
                   c.email,
                   a.phone,
                   c.active
            FROM customer c
            JOIN address a ON a.address_id = c.address_id
            WHERE c.customer_id = ?
        """;
        return jdbcTemplate.queryForObject(sql, customerMapper, customerId);
    }

    // Historial de alquileres + total pagado por alquiler
    public List<RentalHistoryRow> rentalHistory(int customerId) {
        String sql = """
            SELECT r.rental_id,
                   r.last_update AS rental_date,
                   f.title,
                   COALESCE(SUM(p.amount), 0) AS total_paid
            FROM rental r
            JOIN inventory i ON i.inventory_id = r.inventory_id
            JOIN film f ON f.film_id = i.film_id
            LEFT JOIN payment p ON p.rental_id = r.rental_id
            WHERE r.customer_id = ?
            GROUP BY r.rental_id, r.last_update, f.title
            ORDER BY r.last_update DESC
            LIMIT 50
        """;

        return jdbcTemplate.query(sql, rentalMapper, customerId);
    }

    // Total pagado por cliente
    public BigDecimal totalPaidByCustomer(int customerId) {
        String sql = """
            SELECT COALESCE(SUM(amount), 0)
            FROM payment
            WHERE customer_id = ?
        """;
        return jdbcTemplate.queryForObject(sql, BigDecimal.class, customerId);
    }
}
