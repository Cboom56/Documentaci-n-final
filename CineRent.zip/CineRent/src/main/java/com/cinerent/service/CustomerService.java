package com.cinerent.service;

import com.cinerent.dto.CustomerRow;
import com.cinerent.dto.RentalHistoryRow;
import com.cinerent.repository.CustomerDao;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class CustomerService {

    private final CustomerDao customerDao;

    public CustomerService(CustomerDao customerDao) {
        this.customerDao = customerDao;
    }

    public List<CustomerRow> search(String q, int page, int size) {
        return customerDao.searchCustomers(q, page, size);
    }

    public long count(String q) {
        return customerDao.countCustomers(q);
    }

    public CustomerRow getCustomer(int customerId) {
        return customerDao.getCustomer(customerId);
    }

    public List<RentalHistoryRow> history(int customerId) {
        return customerDao.rentalHistory(customerId);
    }

    public BigDecimal totalPaid(int customerId) {
        return customerDao.totalPaidByCustomer(customerId);
    }
}
