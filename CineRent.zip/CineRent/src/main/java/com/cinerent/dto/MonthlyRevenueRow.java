package com.cinerent.dto;

import java.math.BigDecimal;

public class MonthlyRevenueRow {
    private String month; // ej: 2025-07
    private BigDecimal revenue;

    public MonthlyRevenueRow(String month, BigDecimal revenue) {
        this.month = month;
        this.revenue = revenue;
    }

    public String getMonth() { return month; }
    public BigDecimal getRevenue() { return revenue; }
}
