package com.cinerent.dto;

public class TopFilmRow {
    private String title;
    private long rentals;

    public TopFilmRow(String title, long rentals) {
        this.title = title;
        this.rentals = rentals;
    }

    public String getTitle() { return title; }
    public long getRentals() { return rentals; }
}
