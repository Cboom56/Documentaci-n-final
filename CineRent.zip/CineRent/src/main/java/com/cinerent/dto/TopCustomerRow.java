package com.cinerent.dto;

import java.math.BigDecimal;

public class TopCustomerRow {
    private final int customerId;
    private final String fullName;
    private final String email;
    private final BigDecimal totalSpent;

    public TopCustomerRow(int customerId, String fullName, String email, BigDecimal totalSpent) {
        this.customerId = customerId;
        this.fullName = fullName;
        this.email = email;
        this.totalSpent = totalSpent;
    }

    public int getCustomerId() { return customerId; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public BigDecimal getTotalSpent() { return totalSpent; }
}
