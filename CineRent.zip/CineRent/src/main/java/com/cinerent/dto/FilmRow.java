package com.cinerent.dto;

public class FilmRow {
    private int filmId;
    private String title;
    private String rating;
    private Integer releaseYear;
    private Integer length;
    private String category;

    public FilmRow(int filmId, String title, String rating, Integer releaseYear, Integer length, String category) {
        this.filmId = filmId;
        this.title = title;
        this.rating = rating;
        this.releaseYear = releaseYear;
        this.length = length;
        this.category = category;
    }

    public int getFilmId() { return filmId; }
    public String getTitle() { return title; }
    public String getRating() { return rating; }
    public Integer getReleaseYear() { return releaseYear; }
    public Integer getLength() { return length; }
    public String getCategory() { return category; }
}
