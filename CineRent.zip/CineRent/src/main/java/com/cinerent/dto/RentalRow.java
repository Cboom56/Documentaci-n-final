package com.cinerent.dto;

public class RentalRow {
    private final int rentalId;
    private final String rentalDate;     // YYYY-MM-DD HH:MM (texto listo para UI)
    private final int storeId;
    private final String customer;
    private final String filmTitle;

    public RentalRow(int rentalId, String rentalDate, int storeId, String customer, String filmTitle) {
        this.rentalId = rentalId;
        this.rentalDate = rentalDate;
        this.storeId = storeId;
        this.customer = customer;
        this.filmTitle = filmTitle;
    }

    public int getRentalId() { return rentalId; }
    public String getRentalDate() { return rentalDate; }
    public int getStoreId() { return storeId; }
    public String getCustomer() { return customer; }
    public String getFilmTitle() { return filmTitle; }
}
