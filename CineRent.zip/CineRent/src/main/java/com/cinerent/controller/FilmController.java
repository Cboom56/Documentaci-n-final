package com.cinerent.controller;

import com.cinerent.service.FilmSearchService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/films")
public class FilmController {

    private final FilmSearchService filmSearchService;

    public FilmController(FilmSearchService filmSearchService) {
        this.filmSearchService = filmSearchService;
    }

    @GetMapping
    public String search(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String rating,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String actor,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            Model model) {

        var films = filmSearchService.search(title, rating, category, actor, page, size);
        long total = filmSearchService.count(title, rating, category, actor);
        long totalPages = (long) Math.ceil((double) total / size);

        model.addAttribute("films", films);
        model.addAttribute("total", total);
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("totalPages", totalPages);

        model.addAttribute("title", title);
        model.addAttribute("rating", rating);
        model.addAttribute("category", category);
        model.addAttribute("actor", actor);

        return "films/list";
    }
}
