package com.cinerent.controller;

import com.cinerent.service.ReportService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reports")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping
    public String reports(Model model) {
        model.addAttribute("topFilms", reportService.topFilms());
        model.addAttribute("monthlyRevenue", reportService.revenueLast12Months());
        model.addAttribute("topCustomers", reportService.topCustomersBySpending());
        return "reports/index";
    }
}
