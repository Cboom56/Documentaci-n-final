package com.cinerent.dto;

public class CustomerRow {
    private int customerId;
    private String fullName;
    private String email;
    private String phone;
    private boolean active;

    public CustomerRow(int customerId, String fullName, String email, String phone, boolean active) {
        this.customerId = customerId;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.active = active;
    }

    public int getCustomerId() { return customerId; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public boolean isActive() { return active; }
}
