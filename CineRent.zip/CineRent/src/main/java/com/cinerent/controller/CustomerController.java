package com.cinerent.controller;

import com.cinerent.service.CustomerService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping
    public String list(
            @RequestParam(required = false) String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            Model model) {

        var customers = customerService.search(q, page, size);
        long total = customerService.count(q);
        long totalPages = (long) Math.ceil((double) total / size);

        model.addAttribute("customers", customers);
        model.addAttribute("q", q);
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("total", total);
        model.addAttribute("totalPages", totalPages);

        return "customers/list";
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable("id") int id, Model model) {

        var customer = customerService.getCustomer(id);
        var history = customerService.history(id);
        var totalPaid = customerService.totalPaid(id);

        model.addAttribute("customer", customer);
        model.addAttribute("history", history);
        model.addAttribute("totalPaid", totalPaid);

        return "customers/detail";
    }
}
