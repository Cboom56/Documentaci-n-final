package com.cinerent.repository;

import com.cinerent.dto.RentalRow;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Repository
public class RentalReportDao {

    private final JdbcTemplate jdbcTemplate;

    public RentalReportDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<RentalRow> searchRentals(LocalDate from, LocalDate to, Integer storeId, int page, int size) {

        // Usamos last_update como “fecha del alquiler” (tu BD ya la tiene)
        StringBuilder sql = new StringBuilder("""
            SELECT r.rental_id,
                   r.last_update AS rental_date,
                   i.store_id,
                   (c.first_name || ' ' || c.last_name) AS customer,
                   f.title AS film_title
            FROM rental r
            JOIN inventory i ON i.inventory_id = r.inventory_id
            JOIN film f ON f.film_id = i.film_id
            JOIN customer c ON c.customer_id = r.customer_id
            WHERE 1=1
        """);

        List<Object> params = new ArrayList<>();

        if (from != null) {
            sql.append(" AND r.last_update >= ? ");
            params.add(Timestamp.valueOf(from.atStartOfDay()));
        }
        if (to != null) {
            // inclusive: hasta el final del día
            sql.append(" AND r.last_update < ? ");
            params.add(Timestamp.valueOf(to.plusDays(1).atStartOfDay()));
        }
        if (storeId != null) {
            sql.append(" AND i.store_id = ? ");
            params.add(storeId);
        }

        sql.append(" ORDER BY r.last_update DESC ");
        sql.append(" LIMIT ? OFFSET ? ");
        params.add(size);
        params.add(page * size);

        return jdbcTemplate.query(sql.toString(), (rs, rowNum) -> new RentalRow(
                rs.getInt("rental_id"),
                rs.getTimestamp("rental_date").toString(),
                rs.getInt("store_id"),
                rs.getString("customer"),
                rs.getString("film_title")
        ), params.toArray());
    }

    public long countRentals(LocalDate from, LocalDate to, Integer storeId) {

        StringBuilder sql = new StringBuilder("""
            SELECT COUNT(*)
            FROM rental r
            JOIN inventory i ON i.inventory_id = r.inventory_id
            WHERE 1=1
        """);

        List<Object> params = new ArrayList<>();

        if (from != null) {
            sql.append(" AND r.last_update >= ? ");
            params.add(Timestamp.valueOf(from.atStartOfDay()));
        }
        if (to != null) {
            sql.append(" AND r.last_update < ? ");
            params.add(Timestamp.valueOf(to.plusDays(1).atStartOfDay()));
        }
        if (storeId != null) {
            sql.append(" AND i.store_id = ? ");
            params.add(storeId);
        }

        return jdbcTemplate.queryForObject(sql.toString(), Long.class, params.toArray());
    }
}
