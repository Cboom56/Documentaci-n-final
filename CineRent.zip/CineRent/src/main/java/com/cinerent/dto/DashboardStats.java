package com.cinerent.dto;

import java.math.BigDecimal;

public class DashboardStats {
    private long rentalsRecentCount;
    private BigDecimal revenueTotal;
    private long activeCustomers;

    public DashboardStats(long rentalsRecentCount, BigDecimal revenueTotal, long activeCustomers) {
        this.rentalsRecentCount = rentalsRecentCount;
        this.revenueTotal = revenueTotal;
        this.activeCustomers = activeCustomers;
    }

    public long getRentalsRecentCount() { return rentalsRecentCount; }
    public BigDecimal getRevenueTotal() { return revenueTotal; }
    public long getActiveCustomers() { return activeCustomers; }
}
